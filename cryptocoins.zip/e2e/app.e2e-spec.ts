import { CryptocoinsPage } from './app.po';

describe('cryptocoins App', () => {
  let page: CryptocoinsPage;

  beforeEach(() => {
    page = new CryptocoinsPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
