import { Component } from '@angular/core';
import { ChartsModule } from 'ng2-charts';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  constructor(private http: HttpClient){
    var time = new Date()
    this.barChartLabels[0] = time.toString()
  }


  ngOnInit(): void {
    // Make the HTTP request:
    
    setInterval(() =>{
      let clone = [...JSON.parse(JSON.stringify(this.barChartData))];
      var time = new Date()
      // this.barChartLabels.push(time.getMinutes() + '-' + time.getSeconds())
      this.barChartLabels[0] = time.toString()
      
      this.http.get('https://api.coinmarketcap.com/v1/ticker/?limit=10').subscribe(data => {
        
        for (let key in data) {
          // let newData = [...clone[key].data,data[key].price_usd]
          let newData = [data[key].price_usd]
          clone[key].data = newData
        }

        this.barChartData = [...clone]
      });
    } ,50000)

  }

  public barChartOptions:any = {
    scaleShowVerticalLines: false,
    responsive: true
  };
  public barChartLabels:string[] = ['1'];
  public barChartType:string = 'bar';
  public barChartLegend:boolean = true;
 
  public barChartData:any[] = [
    {data: [], label: 'Bitcoin'},
    {data: [], label: 'Ethereum'},
    {data: [], label: 'Bitcoin Cash"'},
    {data: [], label: 'Ripple'},
    {data: [], label: 'Litecoin'},
    {data: [], label: 'Dash'},
    {data: [], label: 'IOTA'},
    {data: [], label: 'NEO'},
    {data: [], label: 'Monero'},
    {data: [], label: 'NEM'},
  ];
 
  // events
  public chartClicked(e:any):void {
    console.log(e);
  }
 
  public chartHovered(e:any):void {
    console.log(e);
  }
 
  public randomize():void {
    // Only Change 3 values

    let barChartData:any[] = [
      {data: [], label: 'Bitcoin'},
      {data: [], label: 'Ethereum'},
      {data: [], label: 'Bitcoin Cash"'},
      {data: [], label: 'Ripple'},
      {data: [], label: 'Litecoin'},
      {data: [], label: 'Dash'},
      {data: [], label: 'IOTA'},
      {data: [], label: 'NEO'},
      {data: [], label: 'Monero'},
      {data: [], label: 'NEM'},
    ];

     var time = new Date()
     this.barChartLabels = []; 
    this.barChartData = barChartData;
    /**
     * (My guess), for Angular to recognize the change in the dataset
     * it has to change the dataset variable directly,
     * so one way around it, is to clone the data, change it and then
     * assign it;
     */
  }
  
}
